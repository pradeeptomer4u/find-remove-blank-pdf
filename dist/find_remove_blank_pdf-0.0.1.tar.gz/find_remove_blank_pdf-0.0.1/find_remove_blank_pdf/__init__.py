# find_remove_blank_pdf/__init__.py
from .sdk import process_report

